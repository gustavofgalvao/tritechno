package beans;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Matricula {
	private int codigo;
	private int codigoAluno;
	private int codigoDisciplina;
	private int matricula;
	private java.util.Date dataMatricula;
	SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
	
	//construtor padrao com conversor de String para Date
	public Matricula(int codigo, int codigoAluno, int codigoDisciplina, int matricula, String dataMatricula) throws ParseException {
		super();
		this.codigo = codigo;
		this.codigoAluno = codigoAluno;
		this.codigoDisciplina = codigoDisciplina;
		this.matricula = matricula;
		this.dataMatricula = formato.parse(dataMatricula);
	}
	
	//construtor padrao
	public Matricula(int codigo, int codigoAluno, int codigoDisciplina, int matricula, Date dataMatricula) {
		super();
		this.codigo = codigo;
		this.codigoAluno = codigoAluno;
		this.codigoDisciplina = codigoDisciplina;
		this.matricula = matricula;
		this.dataMatricula = dataMatricula;
	}

	public Matricula() {
		// TODO Auto-generated constructor stub
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getCodigoAluno() {
		return codigoAluno;
	}

	public void setCodigoAluno(int codigoAluno) {
		this.codigoAluno = codigoAluno;
	}

	public int getCodigoDisciplina() {
		return codigoDisciplina;
	}

	public void setCodigoDisciplina(int codigoDisciplina) {
		this.codigoDisciplina = codigoDisciplina;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	//get com conversor de Java Date para Sql Date
	public java.sql.Date getDataMatricula() {
		return new java.sql.Date(dataMatricula.getTime());
	}
	
	public java.util.Date getJavaDataMatricula() {
		return dataMatricula;
	}

	//set com conversor de String para Date
	public void setDataMatricula(String dataMatricula) throws ParseException {
		this.dataMatricula = formato.parse(dataMatricula);
	}
	
	public void setDataMatricula(Date dataMatricula) {
		this.dataMatricula = dataMatricula;
	}	
	
}
