package beans;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Aluno {

	private int codigo;
	private String nome;
	private int cpf;
	private String email;
	private String senha;
	private java.util.Date dataNascimento;
	private String endereco;
	private int telefone;
	SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
	
	//construtor padrao com conversor de String para Date
	public Aluno(int codigo, String nome, int cpf, String email, String senha, String dataNascimento, String endereco, int telefone) throws ParseException {
		this.codigo = codigo;
		this.nome = nome;
		this.cpf = cpf;
		this.email = email;
		this.senha = senha;
		this.dataNascimento = formato.parse(dataNascimento);
		this.endereco = endereco;
		this.telefone = telefone;
	}
	
	//construtor padrao
	public Aluno(int codigo, String nome, int cpf, String email, String senha, Date dataNascimento, String endereco, int telefone) throws ParseException {
		this.codigo = codigo;
		this.nome = nome;
		this.cpf = cpf;
		this.email = email;
		this.senha = senha;
		this.dataNascimento = dataNascimento;
		this.endereco = endereco;
		this.telefone = telefone;
	}

	public Aluno() {
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCpf() {
		return cpf;
	}

	public void setCpf(int cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	//get com conversor de Java Date para Sql Date
	public java.sql.Date getDataNascimento() {
		java.sql.Date dataSql = new java.sql.Date(dataNascimento.getTime());
		return dataSql;
	}
	
	public java.util.Date getJavaDataNascimento() {
		return dataNascimento;
	}
	
	//set com conversor de String para Date
	public void setDataNascimento(String dataNascimento) throws ParseException {
		this.dataNascimento = formato.parse(dataNascimento);
	}
	
	public void setDataNascimento(Date dataNascimento){
		this.dataNascimento = dataNascimento;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	
}