package beans;

public class Professor {
	private int codigo;
	private int codigoCapitulo;
	private int codigoProgresso;
	private int codigoDisciplina;
	private String nome;
	private int cpf;
	private String email;
	private String senha;
	
	//construtor padrao do professor/admin
	public Professor(int codigo, int codigoCapitulo, int codigoProgresso, int codigoDisciplina, String nome, int cpf, String email, String senha) {
		super();
		this.codigo = codigo;
		this.codigoCapitulo = codigoCapitulo;
		this.codigoProgresso = codigoProgresso;
		this.codigoDisciplina = codigoDisciplina;
		this.nome = nome;
		this.cpf = cpf;
		this.email = email;
		this.senha = senha;
	}
	
	public Professor() {
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getCodigoCapitulo() {
		return codigoCapitulo;
	}

	public void setCodigoCapitulo(int codigoCapitulo) {
		this.codigoCapitulo = codigoCapitulo;
	}

	public int getCodigoProgresso() {
		return codigoProgresso;
	}

	public void setCodigoProgresso(int codigoProgresso) {
		this.codigoProgresso = codigoProgresso;
	}

	public int getCodigoDisciplina() {
		return codigoDisciplina;
	}

	public void setCodigoDisciplina(int codigoDisciplina) {
		this.codigoDisciplina = codigoDisciplina;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCpf() {
		return cpf;
	}

	public void setCpf(int cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	
}