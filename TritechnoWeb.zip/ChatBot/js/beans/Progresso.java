package beans;

public class Progresso {
	private int codigo;
	private int codigoMatricula;
	private int codigoCapitulo;
	private int codigoDisciplina;
	private int status;
	private String avaliacao;
	
	//construtor padrao
	public Progresso(int codigo, int codigoMatricula, int codigoCapitulo, int codigoDisciplina, int status, String avaliacao) {
		super();
		this.codigo = codigo;
		this.codigoMatricula = codigoMatricula;
		this.codigoCapitulo = codigoCapitulo;
		this.codigoDisciplina = codigoDisciplina;
		this.status = status;
		this.avaliacao = avaliacao;
	}

	public Progresso() {
		// TODO Auto-generated constructor stub
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getCodigoMatricula() {
		return codigoMatricula;
	}

	public void setCodigoMatricula(int codigoMatricula) {
		this.codigoMatricula = codigoMatricula;
	}

	public int getCodigoCapitulo() {
		return codigoCapitulo;
	}

	public void setCodigoCapitulo(int codigoCapitulo) {
		this.codigoCapitulo = codigoCapitulo;
	}

	public int getCodigoDisciplina() {
		return codigoDisciplina;
	}

	public void setCodigoDisciplina(int codigoDisciplina) {
		this.codigoDisciplina = codigoDisciplina;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getAvaliacao() {
		return avaliacao;
	}

	public void setAvaliacao(String avaliacao) {
		this.avaliacao = avaliacao;
	}
}
