package beans;

public class Capitulo {
	private int codigo;
	private int codigoDisciplina;
	private String titulo;
	private String documento;
	
	//construtor padrao
	public Capitulo(int codigo, int codigoDisciplina, String titulo, String documento) {
		this.codigo = codigo;
		this.codigoDisciplina = codigoDisciplina;
		this.titulo = titulo;
		this.documento = documento;
	}

	public Capitulo() {
		// TODO Auto-generated constructor stub
	}


	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getCodigoDisciplina() {
		return codigoDisciplina;
	}

	public void setCodigoDisciplina(int codigoDisciplina) {
		this.codigoDisciplina = codigoDisciplina;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}
	
}
