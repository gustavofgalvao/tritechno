package beans;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Disciplina {
	private int codigo;
	private String nome;
	private java.util.Date inicio;
	private java.util.Date termino;
	private int Status;
	SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
	
	//construtor padrao com conversor de String para Date
	public Disciplina(int codigo, String nome, String inicio, String termino, int status) throws ParseException {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.inicio = formato.parse(inicio);
		this.termino = formato.parse(termino);
		Status = status;
	}
	
	//construtor padrao
	public Disciplina(int codigo, String nome, Date inicio, Date termino, int status) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.inicio = inicio;
		this.termino = termino;
		Status = status;
	}


	public Disciplina() {
		// TODO Auto-generated constructor stub
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	//get com conversor de Java Date para Sql Date
	public java.sql.Date getInicio() {
		java.sql.Date dataSql = new java.sql.Date(inicio.getTime());
		return dataSql;
	}

	public java.util.Date getJavaInicio() {
		return inicio;
	}
	
	//set com conversor de String para Date
	public void setInicio(String inicio) throws ParseException {
		this.inicio = formato.parse(inicio);
	}
	
	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}

	//get com conversor de Java Date para Sql Date
	public java.sql.Date getTermino() {
		java.sql.Date dataSql = new java.sql.Date(termino.getTime());
		return dataSql;
	}
	
	
	public java.util.Date getJavaTermino() {
		return termino;
	}

	//set com conversor de String para Date
	public void setTermino(String termino) throws ParseException {
		this.termino = formato.parse(termino);
	}
	
	public void setTermino(Date termino) {
		this.termino = termino;
	}

	public int getStatus() {
		return Status;
	}

	public void setStatus(int status) {
		Status = status;
	}
	
}
