package BO;

import DAO.ProgressoDAO;
import beans.Progresso;

public final class ProgressoBO {
	// Metodo para adicionar um novo Progresso
	public String NovoProgresso(Progresso progresso) throws Exception {
		
		//Verificar se o codigo � invalido
		if(progresso.getCodigo()<=0) {
			return "Codigo do Progresso invalido";
		}
		
		// Verificar se o codigo do progresso ja existe
		ProgressoDAO dao = new ProgressoDAO();
		Progresso p = dao.getProgresso(progresso.getCodigo());
		if(p.getCodigo()>0) {
			return"C�digo ja existe";
		}
		
		//Adicionar pelo pacote DAO
		if(dao.adicionarProgresso(progresso) == 0) {
			dao.fechar();
			return "N�o cadastrou o Progresso";
		}else {
			dao.fechar();
			return "Cadastrou o Progresso com sucesso!!!";
		}
	}
}
