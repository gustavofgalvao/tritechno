package BO;
//BO sempre tera as regras de negocio(codigo sempre ser positivo), requisito funcional(constraint) e padroniza��o(toUppercase).
import DAO.ProfessorDAO;
import beans.Professor;

public class ProfessorBO {
	// Metodo para adicionar um novo Professor
	public String novoProfessor(Professor professor) throws Exception {
		professor.setNome(professor.getNome().toUpperCase());
		if(professor.getNome().length()>100) {
			return "Nome muito Grande";
		}
		
		//Verificar se o codigo � invalido
		if(professor.getCodigo()<=0) {
			return"C�digo negativo";
		}
		
		// Verificar se o codigo do professor/admin ja existe
		ProfessorDAO dao = new ProfessorDAO();
		Professor objeto = dao.getProfessor(professor.getCodigo());
		
		if(objeto.getCodigo()!=0) {
			return"C�digo ja existe";
		}
		
		//Adicionar pelo pacote DAO
		if (dao.addProfessor(professor)==0){
		dao.fechar();
		return "N�o cadastrou";
	}else {
		dao.fechar();
		return"Cadastrado com sucesso!!!";
			
		}
	}
	
	//metodo para consultar por codigo
	public Professor consultarProfessorPorCodigo(int codigo)throws Exception{
		if(codigo<=0) {
			return new Professor();
		}
		ProfessorDAO dao = new ProfessorDAO();
		Professor f = dao.getProfessor(codigo);
		dao.fechar();
		return f;
	}
}
