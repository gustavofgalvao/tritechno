package BO;

import DAO.CapituloDAO;
import beans.Capitulo;

public class CapituloBO {
	// Metodo para adicionar um novo Capitulo
	public String NovoCapitulo(Capitulo capitulo) throws Exception {
		//Verificar se o titulo esta grande ou pequeno demais
		capitulo.setTitulo(capitulo.getTitulo().toUpperCase());
		if(capitulo.getTitulo().length()<3) {
			return "Nessessario pelo menos 3 letras no titulo";
		}
		if(capitulo.getTitulo().length()>15) {
			return "Titulo grande demais, maximo de 15 letras";
		}
		
		//Verificar se o codigo � invalido
		if(capitulo.getCodigo()<=0) {
			return "Codigo do Capitulo invalido";
		}
		
		// Verificar se o codigo do Capitulo ja existe
		CapituloDAO dao = new CapituloDAO();
		Capitulo c = dao.getCapitulo(capitulo.getCodigo());
		if(c.getCodigo()>0) {
			return"C�digo ja existe";
		}
		
		//Adicionar pelo pacote DAO
		if(dao.addCapitulo(capitulo) == 0) {
			dao.fechar();
			return "N�o cadastrou o Aluno";
		}else {
			dao.fechar();
			return "Cadastrado com sucesso!!!";
		}
	}
}
