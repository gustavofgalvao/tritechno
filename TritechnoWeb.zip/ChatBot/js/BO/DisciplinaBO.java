package BO;

import DAO.DisciplinaDAO;
import beans.Disciplina;

public class DisciplinaBO {
	// Metodo para adicionar um nova Disciplina
	public String NovoDisciplina(Disciplina disciplina) throws Exception {
		disciplina.setNome(disciplina.getNome().toUpperCase());
		if(disciplina.getNome().length()<3||disciplina.getNome().length()>10) {
			return"Titulo como caracteres invalidos";
		}
		
		//Verificar se o codigo � invalido
		if(disciplina.getCodigo()<=0) {
			return "Codigo do Capitulo invalido";
		}
		
		// Verificar se o codigo da disciplina ja existe
		DisciplinaDAO dao = new DisciplinaDAO();
		Disciplina d = dao.getDisciplina(disciplina.getCodigo());
		if(d.getCodigo()>0) {
			return"C�digo ja existe";
		}
		
		//Adicionar pelo pacote DAO
		if(dao.adicionarDisciplina(disciplina) == 0) {
			dao.fechar();
			return "N�o cadastrou o Aluno";
		}else {
			dao.fechar();
			return "Cadastrado com sucesso!!!";
		}
	}
}
