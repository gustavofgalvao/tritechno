package BO;

import DAO.MatriculaDAO;
import beans.Matricula;

public class MatriculaBO {
	// Metodo para adicionar um nova Matricula
	public String NovoMatricula(Matricula matricula) throws Exception {
		
		//Verificar se o codigo � invalido
		if(matricula.getCodigo()<=0) {
			return "Codigo da Matricula invalido";
		}
		
		// Verificar se o codigo da matricula ja existe
		MatriculaDAO dao = new MatriculaDAO();
		Matricula m = dao.getMatricula(matricula.getCodigo());
		if(m.getCodigo()>0) {
			return"C�digo da Matriculaja existe";
		}
		
		//Adicionar pelo pacote DAO
		if(dao.adicionarMatricula(matricula) == 0) {
			dao.fechar();
			return "N�o cadastrou a Matricula";
		}else {
			dao.fechar();
			return "Cadastrado da Matricula com sucesso!!!";
		}
	}
}
