package BO;

import DAO.AlunoDAO;
import beans.Aluno;

public class AlunoBO {
	// Metodo para adicionar um novo Aluno
	public String NovoAluno(Aluno aluno) throws Exception{
		//Verificar se nome esta grande ou pequeno demais
		aluno.setNome(aluno.getNome().toUpperCase());
		if(aluno.getNome().length()<3) {
			return "Nessessario pelo menos 3 letras no nome";
		}
		if(aluno.getNome().length()>15) {
			return "Nome grande demais, maximo de 15 letras";
		}
		
		//Verificar se o codigo � invalido
		if(aluno.getCodigo()<=0) {
			return "Codigo do Aluno invalido, Por favor digite um valor maior que 0";
		}
		
		// Verificar se o codigo do aluno ja existe
		AlunoDAO dao = new AlunoDAO();
		Aluno p = dao.getAluno(aluno.getCodigo());
		
		if(p.getCodigo()>0) {
			return"C�digo ja existe, Utilize outro";
		}
		
		//Adicionar pelo pacote DAO
		if(dao.addAluno(aluno) == 0) {
			dao.fechar();
			return "Erro ao cadastrar";
		}else {
			dao.fechar();
			return "Cadastrado com sucesso!!!";
		}
	}
	
	//metodo para consultar por codigo
	public Aluno consultarPorCodigo(int codigo)throws Exception{
		if(codigo<=0) {
			return new Aluno();
		}
		AlunoDAO dao = new AlunoDAO();
		Aluno aluno = dao.getAluno(codigo);
		dao.fechar();
		return aluno;
	}
	
	//metodo para consultar por nome
	public Aluno consultarPorNome(String nome)throws Exception{
		if(nome == null) {
			return new Aluno();
		}
		AlunoDAO dao = new AlunoDAO();
		Aluno aluno = dao.getAlunoNome(nome);
		dao.fechar();
		return aluno;
	}
}
