package Principal;

import BO.ProfessorBO;
import DAO.ProfessorDAO;
import beans.Professor;

public class TesteCadastrarADMIN {

	public static void main(String[] args) throws Exception {
			ProfessorBO bo = new ProfessorBO();
			Professor professor = new Professor(1, 1, 1, 1, "Jose", 1817493302,"admin@gmail.com", "senha321");
			
			System.out.println(bo.novoProfessor(professor));
	}
}
