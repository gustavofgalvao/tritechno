package Principal;

import beans.Aluno;
import BO.AlunoBO;
import DAO.AlunoDAO;

public class TesteCadastraAluno {

	public static void main(String[] args) throws Exception {

		Aluno aluno = new Aluno();
		aluno.setCodigo(1);
		aluno.setNome("kelvin");
		aluno.setCpf(181993007);
		aluno.setEmail("kelvincapitan@Hotmail.com");
		aluno.setSenha("senha123");
		aluno.setDataNascimento("03/09/1998");
		aluno.setEndereco("av alberto ramos");
		aluno.setTelefone(29092828);
		
		AlunoBO bo = new AlunoBO();
		
		System.out.println(bo.NovoAluno(aluno));
	}

}
