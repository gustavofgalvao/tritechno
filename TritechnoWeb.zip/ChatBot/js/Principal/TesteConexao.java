package Principal;

import java.sql.Connection;

import Conexao.Conexao;

public class TesteConexao {

	public static void main(String[] args) {
		Connection minhaConexao=null;
		try {
			 minhaConexao = 
					 Conexao.getConectar();	 
			 System.out.println("conectou com sucesso");
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				minhaConexao.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
}