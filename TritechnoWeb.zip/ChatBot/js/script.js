$(documnet).ready(function(){

import BO.AlunoBO;
	
var attempt = 3;

function validate(){
	
AlunoBO bo = new AlunoBO();
	
var username = document.getElementById("Idnome").value;
var password = document.getElementById("Idsenha").value;
Aluno aluno = bo.consultarPorNome(username);
if ( username == aluno.getNome && password == aluno.getSenha){
alert ("Login com Sucesso");
window.location = "menu.jsp";
return false;
}
else{
attempt --;// Decrementing by one.
alert("Você saiu "+attempt+" attempt;");
//Disabling fields after 3 attempts.
if( attempt == 0){
document.getElementById("Idnome").disabled = true;
document.getElementById("Idsenha").disabled = true;
document.getElementById("entrar").disabled = true;
return false;
}
}
}
})
