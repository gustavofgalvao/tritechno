package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Conexao.Conexao;
import beans.Progresso;

public class ProgressoDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	//metodo para abir a conexao
	public ProgressoDAO() throws Exception{
		con = Conexao.getConectar();
	}
	
	//metodo para consultar progresso pelo codigo
	public Progresso getProgresso(int codigo) throws Exception{
		stmt = con.prepareStatement
		("SELECT * FROM T_SIP_PROGRESSO WHERE CD_PROGRESSO=?");
		stmt.setInt(1, codigo);
		rs = stmt.executeQuery();
		if (rs.next()) {
			return new Progresso(
					rs.getInt("CD_PROGRESSO"),
					rs.getInt("CD_MATRICULA"),
					rs.getInt("CD_CAPITULO"),
					rs.getInt("CD_DISCIPLINA"),
					rs.getInt("ST_STATUS"),
					rs.getString("DS_AVALIACAO")
					);
		}else {
			return new Progresso();
		}
	}
	
	//metodo para apagar o progresso pelo codigo
	public String apagarProgresso(int codigo) throws Exception{
		stmt = con.prepareStatement
		("delete from T_SIP_PROGRESSO where CD_PROGRESSO=?");
		stmt.setInt(1, codigo);
		if (stmt.executeUpdate()>0) {
			return "Deletado com sucesso";
		}else {
			return "Progresso n�o encontrado";
		}
	}
	
	//metodo para adicionar progresso no banco de dados
	public int adicionarProgresso(Progresso progresso) throws Exception{
		stmt = con.prepareStatement
				("INSERT INTO T_SIP_PROGRESSO (CD_PROGRESSO, CD_MATRICULA, CD_CAPITULO, CD_DISCIPLINA, ST_STATUS, DS_AVALIACAO)"
						+ "values (?, ?, ?, ?, ?, ?)");
		stmt.setInt(1, progresso.getCodigo());
		stmt.setInt(2, progresso.getCodigoMatricula());
		stmt.setInt(3, progresso.getCodigoCapitulo());
		stmt.setInt(4, progresso.getCodigoDisciplina());
		stmt.setInt(5, progresso.getStatus());
		stmt.setString(6, progresso.getAvaliacao());
		return stmt.executeUpdate();
	}
	
	//metodo para fechar a conexao
	public void fechar() throws Exception {
		con.close();
	}
}
