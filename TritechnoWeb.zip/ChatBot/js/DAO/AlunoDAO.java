package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Conexao.Conexao;
import beans.Aluno;

public class AlunoDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	//metodo para abir a conexao
	public AlunoDAO() throws Exception{
		con = Conexao.getConectar();
	}
	
	//metodo para consultar aluno pelo codio
	public Aluno getAluno(int codigo)throws Exception{
		stmt = con.prepareStatement
		("SELECT * FROM T_SIP_ALUNO WHERE CD_ALUNO=?");
		stmt.setInt(1, codigo);
		rs = stmt.executeQuery();
		if (rs.next()) {
			return new Aluno(
					rs.getInt("CD_ALUNO"),
					rs.getString("NM_NOME"),
					rs.getInt("NR_CPF"),
					rs.getString("DS_EMAIL"),
					rs.getString("DS_SENHA"),
					rs.getDate("DT_NASCIMENTO"),
					rs.getString("DS_ENDERECO"),
					rs.getInt("NR_TELEFONE")
					);
		}else {
			return new Aluno();
		}
		
	}
	
	//metodo para consultar aluno pelo nome
		public Aluno getAlunoNome(String nome)throws Exception{
			stmt = con.prepareStatement
			("SELECT * FROM T_SIP_ALUNO WHERE NM_NOME=?");
			stmt.setString(1, nome);
			rs = stmt.executeQuery();
			if (rs.next()) {
				return new Aluno(
						rs.getInt("CD_ALUNO"),
						rs.getString("NM_NOME"),
						rs.getInt("NR_CPF"),
						rs.getString("DS_EMAIL"),
						rs.getString("DS_SENHA"),
						rs.getDate("DT_NASCIMENTO"),
						rs.getString("DS_ENDERECO"),
						rs.getInt("NR_TELEFONE")
						);
			}else {
				return new Aluno();
			}
			
		}
	
	//metodo para apagar o aluno pelo codigo
	public String apagarAluno(int codigo) throws Exception{
		stmt = con.prepareStatement
		("delete from T_SIP_ALUNO where CD_ALUNO=?");
		stmt.setInt(1, codigo);
		if (stmt.executeUpdate()>0) {
			return "Deletado com sucesso";
		}else {
			return "Aluno n�o encontrado";
		}
	}
	
	//metodo para adicionar aluno no banco de dados
	public int addAluno(Aluno aluno ) throws Exception {
		stmt = con.prepareStatement("INSERT INTO T_SIP_ALUNO"
				+ "(CD_ALUNO, NM_NOME, NR_CPF, DS_EMAIL, DS_SENHA, DT_NASCIMENTO, DS_ENDERECO, NR_TELEFONE)"
				+ "values (?, ?, ?, ?, ?, ?, ?, ?)");
		stmt.setInt(1, aluno.getCodigo());
		stmt.setString(2, aluno.getNome());
		stmt.setInt(3, aluno.getCpf());
		stmt.setString(4, aluno.getEmail());
		stmt.setString(5, aluno.getSenha());
		stmt.setDate(6, aluno.getDataNascimento());
		stmt.setString(7, aluno.getEndereco());
		stmt.setInt(8, aluno.getTelefone());
		return stmt.executeUpdate();
	}

	//metodo para fechar a conexao
	public void fechar() throws Exception{
		con.close();
		
	}
}
