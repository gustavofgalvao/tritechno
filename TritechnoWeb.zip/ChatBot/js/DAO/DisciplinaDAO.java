package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Conexao.Conexao;
import beans.Disciplina;

public class DisciplinaDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	//metodo para abir a conexao
	public DisciplinaDAO() throws Exception{
		con = Conexao.getConectar();
	}
	
	//metodo para consultar Disciplina pelo codigo
	public Disciplina getDisciplina(int codigo) throws Exception{
		stmt = con.prepareStatement
		("SELECT * FROM T_SIP_DISCIPLINA WHERE CD_Disciplina=?");
		stmt.setInt(1, codigo);
		rs = stmt.executeQuery();
		if (rs.next()) {
			return new Disciplina(
					rs.getInt("CD_DISCIPLINA"),
					rs.getString("NM_NOME"),
					rs.getDate("DT_INICIO"),
					rs.getDate("DT_TERMINO"),
					rs.getInt("ST_STATUS")
					);
		}else {
			return new Disciplina();
		}
	}
	
	//metodo para apagar o disciplina pelo codigo
	public String apagarDisciplina(int codigo) throws Exception{
		stmt = con.prepareStatement
		("delete from T_SIP_DISCIPLINA where CD_DISCIPLINA=?");
		stmt.setInt(1, codigo);
		if (stmt.executeUpdate()>0) {
			return "Deletado com sucesso";
		}else {
			return "Disciplina n�o encontrada";
		}
	}
	
	//metodo para adicionar disciplina no banco de dados
	public int adicionarDisciplina(Disciplina disciplina) throws Exception{
		stmt = con.prepareStatement
				("INSERT INTO T_SIP_DISCIPLINA (CD_DISCIPLINA, NM_NOME, DT_INICIO, DT_TERMINO, ST_STATUS)"
						+ "values (?, ?, ?, ?, ?)");
		stmt.setInt(1, disciplina.getCodigo());
		stmt.setString(2, disciplina.getNome());
		stmt.setDate(3, disciplina.getInicio());
		stmt.setDate(4, disciplina.getTermino());
		stmt.setInt(5, disciplina.getStatus());
		return stmt.executeUpdate();
	}
	
	//metodo para fechar a conexao
	public void fechar() throws Exception {
		con.close();
	}
	
}
