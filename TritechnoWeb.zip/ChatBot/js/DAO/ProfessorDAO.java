package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Conexao.Conexao;
import beans.Professor;

public class ProfessorDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	//metodo para abir a conexao
	public ProfessorDAO() throws Exception{
		con = Conexao.getConectar();
	}
	
	//metodo para consultar prefessor/admin pelo codigo
	public Professor getProfessor(int codigo) 
			throws Exception{
		stmt = con.prepareStatement
		("SELECT * FROM T_SIP_ADMINISTRADOR WHERE CD_ADMIN=?");
		stmt.setInt(1, codigo);
		rs = stmt.executeQuery();
		if (rs.next()) {
			return new Professor(
					rs.getInt("CD_ADMIN"),
					rs.getInt("CD_CAPITULO"),
					rs.getInt("CD_PROGRESSO"),
					rs.getInt("CD_DISCIPLINA"),
					rs.getString("NM_NOME"),
					rs.getInt("NR_CPF"),
					rs.getString("DS_EMAIL"),
					rs.getString("DS_SENHA")
					);
		}else {
			return new Professor();
		}
	}
	
	//metodo para apagar o professor/admin pelo codigo
	public String apagarProfessor(int codigo) throws Exception{
		stmt = con.prepareStatement
		("delete from T_SIP_ADMINISTRADOR where CD_ADMIN=?");
		stmt.setInt(1, codigo);
		if (stmt.executeUpdate()>0) {
			return "Deletado com sucesso";
		}else {
			return "Professor n�o encontrado";
		}
	}
	
	//metodo para adicionar professor/admin no banco de dados
	public int addProfessor(Professor obj) throws Exception{
		stmt = con.prepareStatement
				("INSERT INTO T_SIP_ADMINISTRADOR (CD_ADMIN, CD_CAPITULO, CD_PROGRESSO, CD_DISCIPLINA, NM_NOME, NR_CPF, DS_EMAIL, DS_SENHA)"
						+ "values (?, ?, ?, ?, ?, ?, ?, ?)");
		stmt.setInt(1, obj.getCodigo());
		stmt.setInt(2, obj.getCodigoCapitulo());
		stmt.setInt(3, obj.getCodigoProgresso());
		stmt.setInt(4, obj.getCodigoDisciplina());
		stmt.setString(5, obj.getNome());
		stmt.setInt(6, obj.getCpf());
		stmt.setString(7, obj.getEmail());
		stmt.setString(8, obj.getSenha());
		return stmt.executeUpdate();
	}
	
	//metodo para fechar a conexao
	public void fechar() throws Exception {
		con.close();
	}
	
}





