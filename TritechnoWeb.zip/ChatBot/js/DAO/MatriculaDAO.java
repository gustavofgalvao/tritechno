package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Conexao.Conexao;
import beans.Matricula;

public class MatriculaDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	//metodo para abir a conexao
	public MatriculaDAO() throws Exception{
		con = Conexao.getConectar();
	}
	
	//metodo para consultar matricula pelo codigo
	public Matricula getMatricula(int codigo) throws Exception{
		stmt = con.prepareStatement
		("SELECT * FROM T_SIP_MATRICULA WHERE CD_MATRICULA=?");
		stmt.setInt(1, codigo);
		rs = stmt.executeQuery();
		if (rs.next()) {
			return new Matricula(
					rs.getInt("CD_MATRICULA"),
					rs.getInt("CD_ALUNO"),
					rs.getInt("CD_DISCIPLINA"),
					rs.getInt("NR_MATRICULA"),
					rs.getDate("DT_MATRICULA")
					);
		}else {
			return new Matricula();
		}
	}
	
	//metodo para apagar o matricula pelo codigo
	public String apagarMatricula(int codigo) throws Exception{
		stmt = con.prepareStatement
		("delete from T_SIP_MATRICULA where CD_MATRICULA=?");
		stmt.setInt(1, codigo);
		if (stmt.executeUpdate()>0) {
			return "Deletado com sucesso";
		}else {
			return "Matricula n�o encontrada";
		}
	}
	
	//metodo para adicionar matricula no banco de dados
	public int adicionarMatricula(Matricula matricula) throws Exception{
		stmt = con.prepareStatement
				("INSERT INTO T_SIP_MATRICULA (CD_MATRICULA, CD_ALUNO, CD_DISCIPLINA, NR_MATRICULA, DT_MATRICULA)"
						+ "values (?, ?, ?, ?, ?)");
		stmt.setInt(1, matricula.getCodigo());
		stmt.setInt(2, matricula.getCodigoAluno());
		stmt.setInt(3, matricula.getCodigoDisciplina());
		stmt.setInt(4, matricula.getMatricula());
		stmt.setDate(5, matricula.getDataMatricula());
		return stmt.executeUpdate();
	}
	
	//metodo para fechar a conexao
	public void fechar() throws Exception {
		con.close();
	}
	
}
