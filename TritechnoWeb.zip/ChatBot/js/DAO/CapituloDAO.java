package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Conexao.Conexao;
import beans.Capitulo;

public class CapituloDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	//metodo para abir a conexao
	public CapituloDAO() throws Exception{
		con = Conexao.getConectar();
	}
	
	//metodo para consultar capitulo pelo codigo
	public Capitulo getCapitulo(int codigo) 
			throws Exception{
		stmt = con.prepareStatement
		("SELECT * FROM T_SIP_CAPITULO WHERE CD_CAPITULO=?");
		stmt.setInt(1, codigo);
		rs = stmt.executeQuery();
		if (rs.next()) {
			return new Capitulo(
					rs.getInt("CD_CAPITULO"),
					rs.getInt("CD_DISCIPLINA"),
					rs.getString("DS_TITULO"),
					rs.getString("DS_DOCUMENTO")
					);
		}else {
			return new Capitulo();
		}
	}
	
	//metodo para apagar o capitulo pelo codigo
	public String apagarCapitulo(int codigo) throws Exception{
		stmt = con.prepareStatement
		("delete from T_SIP_CAPITULO where CD_CAPITULO=?");
		stmt.setInt(1, codigo);
		if (stmt.executeUpdate()>0) {
			return "Deletado com sucesso";
		}else {
			return "Capitulo n�o encontrado";
		}
	}
	
	//metodo para adicionar capitulo no banco de dados
	public int addCapitulo(Capitulo capitulo) throws Exception{
		stmt = con.prepareStatement
				("INSERT INTO T_SIP_CAPITULO (CD_CAPITULO, CD_DISCIPLINA, DS_TITULO, DS_DOCUMENTO)"
						+ "values (?, ?, ?, ?)");
		stmt.setInt(1, capitulo.getCodigo());
		stmt.setInt(2, capitulo.getCodigoDisciplina());
		stmt.setString(3, capitulo.getTitulo());
		stmt.setString(4, capitulo.getDocumento());
		return stmt.executeUpdate();
	}
	
	//metodo para fechar a conexao
	public void fechar() throws Exception {
		con.close();
	}
	
}
